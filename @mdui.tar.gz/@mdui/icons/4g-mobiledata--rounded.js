import { __decorate } from "tslib";
import { LitElement } from 'lit';
import { customElement } from 'lit/decorators/custom-element.js';
import { style } from '@mdui/shared/icons/shared/style.js';
import { svgTag } from '@mdui/shared/icons/shared/svg-tag.js';
let Icon4gMobiledata_Rounded = class Icon4gMobiledata_Rounded extends LitElement {
    render() {
        return svgTag('<path d="M8 7c-.55 0-1 .45-1 1v4H5V8c0-.55-.45-1-1-1s-1 .45-1 1v5c0 .55.45 1 1 1h3v2c0 .55.45 1 1 1s1-.45 1-1v-2h1c.55 0 1-.45 1-1s-.45-1-1-1H9V8c0-.55-.45-1-1-1zm9 5c0 .55.45 1 1 1h1v2h-5V9h6c.55 0 1-.45 1-1s-.45-1-1-1h-6c-1.1 0-2 .9-2 2v6c0 1.1.9 2 2 2h5c1.1 0 2-.9 2-2v-3c0-.55-.45-1-1-1h-2c-.55 0-1 .45-1 1z"/>');
    }
};
Icon4gMobiledata_Rounded.styles = style;
Icon4gMobiledata_Rounded = __decorate([
    customElement('mdui-icon-4g-mobiledata--rounded')
], Icon4gMobiledata_Rounded);
export { Icon4gMobiledata_Rounded };
