import { __decorate } from "tslib";
import { LitElement } from 'lit';
import { customElement } from 'lit/decorators/custom-element.js';
import { style } from '@mdui/shared/icons/shared/style.js';
import { svgTag } from '@mdui/shared/icons/shared/svg-tag.js';
let Icon30fpsSelect_TwoTone = class Icon30fpsSelect_TwoTone extends LitElement {
    render() {
        return svgTag('<path d="M4 4v2h5v2H5v2h4v2H4v2h5c1.1 0 2-.9 2-2v-1.5c0-.83-.17-1.5-1-1.5.83 0 1-.67 1-1.5V6c0-1.1-.9-2-2-2H4zm14 0c1.1 0 2 .9 2 2v6c0 1.1-.9 2-2 2h-3c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2h3zm0 2h-3v6h3V6zM5 22H3v-5h2v5zm4 0H7v-5h2v5zm4 0h-2v-5h2v5zm8 0h-6v-5h6v5z"/>');
    }
};
Icon30fpsSelect_TwoTone.styles = style;
Icon30fpsSelect_TwoTone = __decorate([
    customElement('mdui-icon-30fps-select--two-tone')
], Icon30fpsSelect_TwoTone);
export { Icon30fpsSelect_TwoTone };
