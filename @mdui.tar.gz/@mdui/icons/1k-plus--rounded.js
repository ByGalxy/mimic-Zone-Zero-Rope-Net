import { __decorate } from "tslib";
import { LitElement } from 'lit';
import { customElement } from 'lit/decorators/custom-element.js';
import { style } from '@mdui/shared/icons/shared/style.js';
import { svgTag } from '@mdui/shared/icons/shared/svg-tag.js';
let Icon1kPlus_Rounded = class Icon1kPlus_Rounded extends LitElement {
    render() {
        return svgTag('<path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM8.25 15c-.41 0-.75-.34-.75-.75V10.5h-.75c-.41 0-.75-.34-.75-.75S6.34 9 6.75 9H8c.55 0 1 .45 1 1v4.25c0 .41-.34.75-.75.75zm5.29-.27L12 12.75v1.55c0 .39-.31.7-.7.7h-.1c-.39 0-.7-.31-.7-.7V9.7c0-.39.31-.7.7-.7h.09c.4 0 .71.31.71.7v1.55l1.54-1.98a.698.698 0 0 1 1.11.85L13.25 12l1.41 1.88c.34.46.01 1.12-.57 1.12-.21 0-.42-.1-.55-.27zm4.96-2.23h-1v1c0 .28-.22.5-.5.5s-.5-.22-.5-.5v-1h-1c-.28 0-.5-.22-.5-.5s.22-.5.5-.5h1v-1c0-.28.22-.5.5-.5s.5.22.5.5v1h1c.28 0 .5.22.5.5s-.22.5-.5.5z"/>');
    }
};
Icon1kPlus_Rounded.styles = style;
Icon1kPlus_Rounded = __decorate([
    customElement('mdui-icon-1k-plus--rounded')
], Icon1kPlus_Rounded);
export { Icon1kPlus_Rounded };
