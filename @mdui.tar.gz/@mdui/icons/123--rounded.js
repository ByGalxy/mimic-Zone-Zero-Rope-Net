import { __decorate } from "tslib";
import { LitElement } from 'lit';
import { customElement } from 'lit/decorators/custom-element.js';
import { style } from '@mdui/shared/icons/shared/style.js';
import { svgTag } from '@mdui/shared/icons/shared/svg-tag.js';
let Icon123_Rounded = class Icon123_Rounded extends LitElement {
    render() {
        return svgTag('<path d="M4.75 10.5c-.41 0-.75-.34-.75-.75S4.34 9 4.75 9H6c.55 0 1 .45 1 1v4.25c0 .41-.34.75-.75.75s-.75-.34-.75-.75V10.5h-.75zm5-1.5c-.41 0-.75.34-.75.75s.34.75.75.75H12v1h-2c-.55 0-1 .45-1 1V14c0 .55.45 1 1 1h2.75c.41 0 .75-.34.75-.75s-.34-.75-.75-.75H10.5v-1h2c.55 0 1-.45 1-1V10c0-.55-.45-1-1-1H9.75zm8.75 6c.55 0 1-.45 1-1v-4c0-.55-.45-1-1-1h-2.75c-.41 0-.75.34-.75.75s.34.75.75.75H18v1h-1.5c-.28 0-.5.22-.5.5s.22.5.5.5H18v1h-2.25c-.41 0-.75.34-.75.75s.34.75.75.75h2.75z"/>');
    }
};
Icon123_Rounded.styles = style;
Icon123_Rounded = __decorate([
    customElement('mdui-icon-123--rounded')
], Icon123_Rounded);
export { Icon123_Rounded };
