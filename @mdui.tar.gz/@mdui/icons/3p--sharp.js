import { __decorate } from "tslib";
import { LitElement } from 'lit';
import { customElement } from 'lit/decorators/custom-element.js';
import { style } from '@mdui/shared/icons/shared/style.js';
import { svgTag } from '@mdui/shared/icons/shared/svg-tag.js';
let Icon3p_Sharp = class Icon3p_Sharp extends LitElement {
    render() {
        return svgTag('<path d="M2 2v20l4-4h16V2H2zm10 4c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm4 8H8v-.57c0-.81.48-1.53 1.22-1.85a6.95 6.95 0 0 1 5.56 0A2.01 2.01 0 0 1 16 13.43V14z"/>');
    }
};
Icon3p_Sharp.styles = style;
Icon3p_Sharp = __decorate([
    customElement('mdui-icon-3p--sharp')
], Icon3p_Sharp);
export { Icon3p_Sharp };
