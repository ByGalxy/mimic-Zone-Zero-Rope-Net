import { __decorate } from "tslib";
import { LitElement } from 'lit';
import { customElement } from 'lit/decorators/custom-element.js';
import { style } from '@mdui/shared/icons/shared/style.js';
import { svgTag } from '@mdui/shared/icons/shared/svg-tag.js';
let Icon5g_Outlined = class Icon5g_Outlined extends LitElement {
    render() {
        return svgTag('<path d="M16.5 13H19v2h-5V9h7c0-1.1-.9-2-2-2h-5c-1.1 0-2 .9-2 2v6c0 1.1.9 2 2 2h5c1.1 0 2-.9 2-2v-4h-4.5v2zM3 13h5v2H3v2h5c1.1 0 2-.9 2-2v-2c0-1.1-.9-2-2-2H5V9h5V7H3v6z"/>');
    }
};
Icon5g_Outlined.styles = style;
Icon5g_Outlined = __decorate([
    customElement('mdui-icon-5g--outlined')
], Icon5g_Outlined);
export { Icon5g_Outlined };
