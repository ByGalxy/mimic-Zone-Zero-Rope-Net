import { __decorate } from "tslib";
import { LitElement } from 'lit';
import { customElement } from 'lit/decorators/custom-element.js';
import { style } from '@mdui/shared/icons/shared/style.js';
import { svgTag } from '@mdui/shared/icons/shared/svg-tag.js';
let Icon7k_Sharp = class Icon7k_Sharp extends LitElement {
    render() {
        return svgTag('<path d="M21 3H3v18h18V3zM9.5 15H7.75l1.38-4.5H6.5V9h4.86L9.5 15zm8.5 0h-1.75l-1.75-2.25V15H13V9h1.5v2.25L16.25 9H18l-2.25 3L18 15z"/>');
    }
};
Icon7k_Sharp.styles = style;
Icon7k_Sharp = __decorate([
    customElement('mdui-icon-7k--sharp')
], Icon7k_Sharp);
export { Icon7k_Sharp };
